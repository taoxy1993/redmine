class Compile < ActiveRecord::Base
  unloadable
end
