class CompileController < ApplicationController
  unloadable
  
  before_filter :find_project, :authorize
  
  def index
    @compile = Compile.find(:all)
  end
  
  def new
    if request.post?
      @produce = Compile.find_by_produce(params[:new])
      if @produce 
           flash[:notice] = "产品已经被创建过！！！"
           redirect_to :controller => 'compile', :action => 'index', :id => @project
      else
        @compile = Compile.new(:project_id => @project,:produce => params[:new])
        if @compile.save
          flash[:notice] = "创建成功！"
          redirect_to :controller => 'compile', :action => 'index', :id => @project
        end
      end
    end
  end
  
  def destroy
    @compile = Compile.find_by_produce(params[:produce])
    @compile.destroy
    flash[:notice] = "删除成功！"
    redirect_to :controller => 'compile', :action => 'index', :id => @project
  end
  
  private

  def find_project
    # @project variable must be set before calling the authorize filter
    @project = Project.find(params[:id]) 
  end
end
  
