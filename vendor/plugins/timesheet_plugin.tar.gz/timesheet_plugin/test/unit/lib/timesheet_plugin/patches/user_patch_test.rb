require File.dirname(__FILE__) + '/../../../../test_helper'

class TimesheetPlugin::Patches::UserTest < ActionController::TestCase

  should "be tested"
end
