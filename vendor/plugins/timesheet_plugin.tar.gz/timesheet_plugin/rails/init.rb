require File.dirname(__FILE__) + "/../init"
