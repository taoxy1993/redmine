Autotest.add_discovery do
  "rails"
end
