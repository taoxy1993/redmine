# Wrappers around the Redmine core API changes between versions
module TimesheetCompatibility
end
